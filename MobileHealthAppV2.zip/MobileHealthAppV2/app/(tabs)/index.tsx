import { Ionicons } from "@expo/vector-icons";
import { RefreshControl } from "react-native";

import React, {
  createContext,
  FC,
  useCallback,
  useContext,
  useEffect,
  useState,
} from "react";
import {
  ActivityIndicator,
  Alert,
  FlatList,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";

// --- 1. TYPESCRIPT INTERFACES & CONFIGURATION ---

type Role = "patient" | "worker" | "admin";

interface User {
  id: string; // Client-side mapped ID from MongoDB's _id
  _id: string; // MongoDB original ID
  email: string;
  role: Role;
  name: string;
  healthId?: string;
  title?: string;
  availableDays?: string[];
}

interface Worker extends User {
  title: string;
  availableDays: string[];
}

interface Appointment {
  id: string;
  patientId: string | { _id: string; name: string };
  workerId: string | { _id: string; name: string };
  patientObjectId: string; // Used by worker to issue Rx
  workerName: string;
  patientName?: string;
  date: string;
  time: string;
  reason: string;
  status: "booked" | "cancelled" | "completed";
}

interface Prescription {
  id: string;
  patientId: string;
  workerId: string;
  workerName: string;
  dateIssued: string;
  medication: string;
  dosage: string;
  instructions: string;
  status: string;
}

const ROLES = {
  PATIENT: "patient" as Role,
  HEALTH_WORKER: "worker" as Role,
  ADMIN: "admin" as Role,
};

// --- 2. API SERVICE LAYER (REAL FETCH IMPLEMENTATION) ---

// NOTE: BASE_URL is set to loopback address 10.0.2.2 for Android/iOS emulator compatibility
const BASE_URL: string =
  Platform.OS === "android"
    ? "http://10.0.2.2:3000/api"
    : "http://localhost:3000/api";

interface AuthResponse {
  user: User;
  // token?: string; // JWT token would be here in a real app
}

interface ApiService {
  login: (email: string, password: string) => Promise<AuthResponse>;
  signup: (
    name: string,
    email: string,
    password: string
  ) => Promise<AuthResponse>;
  forgotPassword: (email: string) => Promise<{ message: string }>;
  getAllWorkers: () => Promise<Worker[]>;
  getUserDetails: (userId: string) => Promise<User | undefined>;
  getAppointments: (userId: string, role: Role) => Promise<any[]>;
  createAppointment: (
    patientId: string,
    workerId: string,
    date: string,
    time: string,
    reason: string
  ) => Promise<any>;
  cancelAppointment: (appointmentId: string) => Promise<any>;
  getPrescriptions: (userId: string, role: Role) => Promise<any[]>;
  issuePrescription: (
    patientId: string,
    workerId: string,
    medication: string,
    dosage: string,
    instructions: string
  ) => Promise<any>;
  getAllUsers: () => Promise<User[]>;
  handleResponse: (response: Response) => Promise<any>;
  updateRole: (userId: string, newRole: Role) => Promise<User>;
}

const api: ApiService = {
  async handleResponse(response: Response): Promise<any> {
    const contentType = response.headers.get("content-type");
    const json =
      contentType && contentType.includes("application/json")
        ? await response.json()
        : {};

    if (!response.ok) {
      const message =
        json.message || response.statusText || "An unknown error occurred.";
      throw new Error(message);
    }
    return json;
  },

  // --- AUTH ---
  async login(email, password) {
    const response = await fetch(`${BASE_URL}/auth/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });
    return this.handleResponse(response) as Promise<AuthResponse>;
  },

  async signup(name, email, password) {
    const response = await fetch(`${BASE_URL}/auth/signup`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, email, password }),
    });
    return this.handleResponse(response) as Promise<AuthResponse>;
  },

  async forgotPassword(email) {
    const response = await fetch(`${BASE_URL}/auth/forgot-password`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email }),
    });
    return this.handleResponse(response);
  },

  // --- WORKER & USER LOOKUP ---
  async getAllWorkers() {
    const response = await fetch(`${BASE_URL}/workers`);
    return this.handleResponse(response) as Promise<Worker[]>;
  },

  async getUserDetails(userId) {
    const response = await fetch(`${BASE_URL}/admin/users`);
    const users = (await this.handleResponse(response)) as User[];
    return users.find((u) => u._id === userId);
  },

  // --- APPOINTMENTS (C, R, U) ---
  async getAppointments(userId, role) {
    const response = await fetch(`${BASE_URL}/appointments/${userId}/${role}`);
    return this.handleResponse(response); // Returns populated objects
  },

  async createAppointment(patientId, workerId, date, time, reason) {
    const response = await fetch(`${BASE_URL}/appointments`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ patientId, workerId, date, time, reason }),
    });
    return this.handleResponse(response);
  },

  async cancelAppointment(appointmentId) {
    const response = await fetch(
      `${BASE_URL}/appointments/${appointmentId}/cancel`,
      {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
      }
    );
    return this.handleResponse(response);
  },

  // --- PRESCRIPTIONS (C, R) ---
  async getPrescriptions(userId, role) {
    const response = await fetch(`${BASE_URL}/prescriptions/${userId}/${role}`);
    return this.handleResponse(response);
  },

  async issuePrescription(
    patientId,
    workerId,
    medication,
    dosage,
    instructions
  ) {
    const response = await fetch(`${BASE_URL}/prescriptions`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        patientId,
        workerId,
        medication,
        dosage,
        instructions,
      }),
    });
    return this.handleResponse(response);
  },

  // --- ADMIN (R, U) ---
  async getAllUsers() {
    const response = await fetch(`${BASE_URL}/admin/users`);
    return this.handleResponse(response);
  },

  async updateRole(userId, newRole) {
    const response = await fetch(`${BASE_URL}/admin/users/${userId}/role`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ newRole }),
    });
    return this.handleResponse(response) as Promise<User>;
  },
};

// --- 3. AUTH & STATE CONTEXT ---

interface AuthContextType {
  user: User | null;
  api: ApiService;
  login: (email: string, password: string) => Promise<boolean>;
  signup: (name: string, email: string, password: string) => Promise<boolean>;
  logout: () => void;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const AuthProvider: FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const login = useCallback(
    async (email: string, password: string): Promise<boolean> => {
      setIsLoading(true);
      try {
        const { user: authUser } = await api.login(email, password);
        setUser({ ...authUser, id: authUser._id });
        return true;
      } catch (error: any) {
        Alert.alert("Login Failed", error.message);
        return false;
      } finally {
        setIsLoading(false);
      }
    },
    []
  );

  const signup = useCallback(
    async (name: string, email: string, password: string): Promise<boolean> => {
      setIsLoading(true);
      try {
        const { user: newUser } = await api.signup(name, email, password);
        setUser({ ...newUser, id: newUser._id });
        Alert.alert("Success", "Account created! Welcome to Mobile Health.");
        return true;
      } catch (error: any) {
        Alert.alert("Sign Up Failed", error.message);
        return false;
      } finally {
        setIsLoading(false);
      }
    },
    []
  );

  const logout = useCallback(() => {
    setUser(null);
  }, []);

  const contextValue: AuthContextType = {
    user,
    api,
    login,
    signup,
    logout,
    isLoading,
  };

  if (isLoading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size='large' color='#007bff' />
        <Text style={styles.textBase}>Connecting to server...</Text>
      </View>
    );
  }

  return (
    <AuthContext.Provider value={contextValue}>{children}</AuthContext.Provider>
  );
};

const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};

// --- 4. SHARED COMPONENTS ---

interface ScreenTitleProps {
  children: React.ReactNode;
}
const ScreenTitle: FC<ScreenTitleProps> = ({ children }) => (
  <Text style={styles.screenTitle}>{children}</Text>
);

interface ButtonProps {
  onPress: () => void;
  title: string;
  style?: object;
  textStyle?: object;
  disabled?: boolean;
}
const Button: FC<ButtonProps> = ({
  onPress,
  title,
  style = {},
  textStyle = {},
  disabled = false,
}) => (
  <TouchableOpacity
    onPress={disabled ? () => {} : onPress}
    style={[styles.button, disabled && styles.buttonDisabled, style]}
    activeOpacity={0.7}
  >
    <Text style={[styles.buttonText, textStyle]}>{title}</Text>
  </TouchableOpacity>
);

interface NavHeaderProps {
  name: string;
  role: Role;
  onLogout: () => void;
}
const NavHeader: FC<NavHeaderProps> = ({ name, role, onLogout }) => (
  <View style={styles.header}>
    <View>
      <Text style={styles.headerText}>Mobile Health App</Text>
      <Text style={styles.headerSubText}>
        Logged in as: {name} ({role.toUpperCase()})
      </Text>
    </View>
    <Button
      title='Logout'
      onPress={onLogout}
      style={styles.logoutButton}
      textStyle={styles.logoutButtonText}
    />
  </View>
);

interface CardProps {
  children: React.ReactNode;
  style?: object;
}
const Card: FC<CardProps> = ({ children, style = {} }) => (
  <View style={[styles.card, style]}>{children}</View>
);

// --- 5. AUTHENTICATION SCREENS ---

interface AuthScreenProps {
  setScreen: (screen: "login" | "signup" | "forgot") => void;
}

const LoginScreen: FC<AuthScreenProps> = ({ setScreen }) => {
  const { login } = useAuth();
  const [email, setEmail] = useState<string>("patient@health.com");
  const [password, setPassword] = useState<string>("password");
  const [isLoggingIn, setIsLoggingIn] = useState<boolean>(false);

  const handleLogin = async () => {
    if (!email || !password) {
      Alert.alert("Error", "Please enter both email and password.");
      return;
    }
    setIsLoggingIn(true);
    await login(email, password);
    setIsLoggingIn(false);
  };

  return (
    <View style={styles.authContainer}>
      <ScreenTitle>Welcome Back</ScreenTitle>
      <Text style={styles.subText}>Sign in to manage your healthcare.</Text>

      <Card style={styles.inputCard}>
        <TextInput
          style={styles.input}
          placeholder='Email'
          value={email}
          onChangeText={setEmail}
          keyboardType='email-address'
          autoCapitalize='none'
        />
        <TextInput
          style={styles.input}
          placeholder='Password'
          value={password}
          onChangeText={setPassword}
          secureTextEntry
        />
      </Card>

      <Button
        title={isLoggingIn ? "Logging In..." : "Login"}
        onPress={handleLogin}
        disabled={isLoggingIn}
      />

      <View style={styles.authLinkContainer}>
        <TouchableOpacity
          onPress={() => setScreen("forgot")}
          disabled={isLoggingIn}
        >
          <Text style={styles.forgotPasswordText}>Forgot Password?</Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => setScreen("signup")}
          disabled={isLoggingIn}
        >
          <Text style={styles.switchButtonText}>Sign Up</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.mockUserContainer}>
        <Text style={styles.mockUserTitle}>
          Mock User Credentials (For Demo):
        </Text>
        <Text style={styles.mockUserText}>
          Patient: patient@health.com / password
        </Text>
        <Text style={styles.mockUserText}>
          Worker: doctor@health.com / password
        </Text>
        <Text style={styles.mockUserText}>
          Admin: admin@health.com / password
        </Text>
      </View>
    </View>
  );
};

const SignUpScreen: FC<AuthScreenProps> = ({ setScreen }) => {
  const { signup } = useAuth();
  const [name, setName] = useState<string>("");
  const [email, setEmail] = useState<string>("");
  const [password, setPassword] = useState<string>("");
  const [confirmPassword, setConfirmPassword] = useState<string>("");
  const [isSigningUp, setIsSigningUp] = useState<boolean>(false);

  const handleSignUp = async () => {
    if (!name || !email || !password || !confirmPassword) {
      Alert.alert("Error", "Please fill in all fields.");
      return;
    }
    if (password !== confirmPassword) {
      Alert.alert("Error", "Passwords do not match.");
      return;
    }
    if (!email.includes("@") || !email.includes(".")) {
      Alert.alert("Error", "Please enter a valid email address.");
      return;
    }
    setIsSigningUp(true);
    await signup(name, email, password);
    setIsSigningUp(false);
  };

  return (
    <View style={styles.authContainer}>
      <ScreenTitle>Create Patient Account</ScreenTitle>
      <Text style={styles.subText}>Quick and secure registration.</Text>

      <Card style={styles.inputCard}>
        <TextInput
          style={styles.input}
          placeholder='Full Name'
          value={name}
          onChangeText={setName}
        />
        <TextInput
          style={styles.input}
          placeholder='Email'
          value={email}
          onChangeText={setEmail}
          keyboardType='email-address'
          autoCapitalize='none'
        />
        <TextInput
          style={styles.input}
          placeholder='Password (Min 6 chars)'
          value={password}
          onChangeText={setPassword}
          secureTextEntry
        />
        <TextInput
          style={styles.input}
          placeholder='Confirm Password'
          value={confirmPassword}
          onChangeText={setConfirmPassword}
          secureTextEntry
        />
      </Card>

      <Button
        title={isSigningUp ? "Signing Up..." : "Sign Up"}
        onPress={handleSignUp}
        disabled={isSigningUp}
      />
      <TouchableOpacity
        onPress={() => setScreen("login")}
        style={styles.switchButton}
        disabled={isSigningUp}
      >
        <Text style={styles.switchButtonText}>
          Already have an account? Login
        </Text>
      </TouchableOpacity>
    </View>
  );
};

const ForgotPasswordScreen: FC<AuthScreenProps> = ({ setScreen }) => {
  const { api } = useAuth();
  const [email, setEmail] = useState<string>("");
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  const handleSubmit = async () => {
    if (!email || !email.includes("@")) {
      Alert.alert("Error", "Please enter a valid email address.");
      return;
    }

    setIsSubmitting(true);
    try {
      await api.forgotPassword(email);
      Alert.alert(
        "Password Reset Initiated",
        "If an account exists for that email, a password reset link has been sent to your inbox."
      );
      setScreen("login"); // Navigate back to login
    } catch (error: any) {
      // Note: The backend is configured to give a generic success message for security
      Alert.alert(
        "Error",
        error.message || "Could not process request. Please try again later."
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <View style={styles.authContainer}>
      <ScreenTitle>Reset Password</ScreenTitle>
      <Text style={styles.subText}>
        Enter your email to receive a password reset link.
      </Text>

      <Card style={styles.inputCard}>
        <TextInput
          style={styles.input}
          placeholder='Email Address'
          value={email}
          onChangeText={setEmail}
          keyboardType='email-address'
          autoCapitalize='none'
        />
      </Card>

      <Button
        title={isSubmitting ? "Sending Link..." : "Send Reset Link"}
        onPress={handleSubmit}
        disabled={isSubmitting}
      />
      <TouchableOpacity
        onPress={() => setScreen("login")}
        style={styles.switchButton}
        disabled={isSubmitting}
      >
        <Text style={styles.switchButtonText}>← Back to Login</Text>
      </TouchableOpacity>
    </View>
  );
};

// --- 6. PATIENT VIEW (User Role: 'patient') ---

interface PatientScreenProps {
  setScreen: (screen: "dashboard" | "book") => void;
}
const PatientBookingScreen: FC<PatientScreenProps> = ({ setScreen }) => {
  const { user, api } = useAuth();
  const [selectedWorkerId, setSelectedWorkerId] = useState<string | null>(null);
  const [selectedDate, setSelectedDate] = useState<string | null>(null);
  const [reason, setReason] = useState<string>("");
  const [isBooking, setIsBooking] = useState<boolean>(false);
  const [healthcareWorkers, setHealthcareWorkers] = useState<Worker[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  useEffect(() => {
    const fetchWorkers = async () => {
      try {
        const workers = await api.getAllWorkers();
        setHealthcareWorkers(workers.map((w) => ({ ...w, id: w._id })));
      } catch (error: any) {
        Alert.alert(
          "Error",
          `Could not load healthcare providers: ${error.message}`
        );
      } finally {
        setIsLoading(false);
      }
    };
    fetchWorkers();
  }, []);

  const availableTimes: string[] = [
    "09:00",
    "10:00",
    "11:00",
    "14:00",
    "15:00",
  ];

  const handleBooking = async () => {
    if (!selectedWorkerId || !selectedDate || !reason || !user) {
      Alert.alert("Error", "Please select a provider, date, and reason.");
      return;
    }
    setIsBooking(true);
    try {
      await api.createAppointment(
        user.id,
        selectedWorkerId,
        selectedDate,
        availableTimes[0],
        reason
      );
      Alert.alert(
        "Success",
        "Appointment booked successfully! You will receive a confirmation shortly."
      );
      setScreen("dashboard");
    } catch (error: any) {
      Alert.alert("Booking Failed", error.message);
    } finally {
      setIsBooking(false);
    }
  };

  if (isLoading) {
    return (
      <ActivityIndicator
        style={{ flex: 1 }}
        size='large'
        color={primaryColor}
      />
    );
  }

  return (
    <ScrollView
      style={styles.screenContainer}
      contentContainerStyle={{ paddingBottom: 100 }}
    >
      <ScreenTitle>Book Appointment</ScreenTitle>
      <Button
        title='← Back to Dashboard'
        onPress={() => setScreen("dashboard")}
        style={{ marginBottom: 20, backgroundColor: "#6c757d" }}
      />

      <Text style={styles.label}>1. Select Healthcare Provider</Text>
      <FlatList
        horizontal
        data={healthcareWorkers}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={[
              styles.providerTile,
              selectedWorkerId === item.id && styles.providerSelected,
            ]}
            onPress={() => setSelectedWorkerId(item.id)}
          >
            <Ionicons name='person-circle-outline' size={30} color='#007bff' />
            <Text style={styles.providerName}>{item.name}</Text>
            <Text style={styles.providerTitle}>{item.title}</Text>
          </TouchableOpacity>
        )}
      />

      {selectedWorkerId && (
        <>
          <Text style={styles.label}>
            2. Select Date (Mock Date: 2025-11-15)
          </Text>
          <TouchableOpacity
            style={[
              styles.datePickerButton,
              selectedDate && styles.dateSelected,
            ]}
            onPress={() => setSelectedDate("2025-11-15")}
          >
            <Text style={styles.datePickerText}>
              {selectedDate || "Tap to Select Date"}
            </Text>
            <Text style={styles.datePickerTime}>
              {selectedDate
                ? `Available Time: ${availableTimes[0]}`
                : "Select Provider First"}
            </Text>
          </TouchableOpacity>

          <Text style={styles.label}>3. Reason for Visit</Text>
          <TextInput
            style={styles.textArea}
            placeholder='e.g., Annual checkup, flu symptoms, prescription renewal...'
            value={reason}
            onChangeText={setReason}
            multiline
            numberOfLines={4}
          />

          <Button
            title={isBooking ? "Booking..." : "Confirm Appointment"}
            onPress={handleBooking}
            disabled={isBooking || !selectedDate || !reason}
            style={{ marginTop: 20 }}
          />
        </>
      )}
    </ScrollView>
  );
};

const PatientDashboard: FC<PatientScreenProps> = ({ setScreen }) => {
  const { user, api } = useAuth();
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [prescriptions, setPrescriptions] = useState<Prescription[]>([]);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);

  const fetchData = useCallback(async () => {
    setIsRefreshing(true);
    if (!user) {
      setIsRefreshing(false);
      return;
    }
    try {
      const appsData: any[] = await api.getAppointments(user.id, user.role);
      const rxsData: any[] = await api.getPrescriptions(user.id, user.role);

      const formattedApps: Appointment[] = appsData.map((a) => ({
        ...a,
        id: a._id,
        workerName: a.workerId?.name || "Unknown Provider",
        patientObjectId: a.patientId?._id || a.patientId,
      }));

      const formattedRxs: Prescription[] = rxsData.map((r) => ({
        ...r,
        id: r._id,
        workerName: r.workerId?.name || "Unknown Provider",
      }));

      setAppointments(formattedApps);
      setPrescriptions(formattedRxs);
    } catch (error: any) {
      Alert.alert(
        "Data Load Error",
        `Failed to load data: ${error.message}. Ensure the Node.js server is running and initialized.`
      );
    } finally {
      setIsRefreshing(false);
    }
  }, [user]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handleCancel = async (id: string) => {
    try {
      await api.cancelAppointment(id);
      Alert.alert("Success", "Appointment cancelled.");
      fetchData();
    } catch (error: any) {
      Alert.alert("Cancellation Failed", error.message);
    }
  };

  const renderAppointment = ({ item }: { item: Appointment }) => (
    <Card style={styles.listItem}>
      <Text style={styles.listTitle}>{item.workerName}</Text>
      <Text style={styles.listDetail}>
        Date: {item.date} at {item.time}
      </Text>
      <Text style={styles.listDetail}>Reason: {item.reason}</Text>
      <Text
        style={[
          styles.listStatus,
          item.status === "booked"
            ? styles.statusBooked
            : styles.statusCancelled,
        ]}
      >
        Status: {item.status.toUpperCase()}
      </Text>
      {item.status === "booked" && (
        <Button
          title='Cancel'
          onPress={() => handleCancel(item.id)}
          style={styles.cancelButton}
          textStyle={styles.cancelButtonText}
          disabled={isRefreshing}
        />
      )}
    </Card>
  );

  const renderPrescription = ({ item }: { item: Prescription }) => (
    <Card style={styles.listItem}>
      <Text style={styles.listTitle}>
        {item.medication} - {item.dosage}
      </Text>
      <Text style={styles.listDetail}>
        Issued By: {item.workerName} on {item.dateIssued}
      </Text>
      <Text style={styles.listDetail}>Instructions: {item.instructions}</Text>
      <Text style={[styles.listStatus, styles.statusFilled]}>
        Status: {item.status.toUpperCase()}
      </Text>
    </Card>
  );

  return (
    <ScrollView
      style={styles.screenContainer}
      contentContainerStyle={{ paddingBottom: 100 }}
      refreshControl={
        <RefreshControl
          refreshing={isRefreshing}
          onRefresh={fetchData}
          colors={[primaryColor]}
          tintColor={primaryColor}
        />
      }
    >
      <ScreenTitle>My Health Dashboard</ScreenTitle>
      {isRefreshing && (
        <Text style={{ textAlign: "center", color: "#6c757d" }}>
          Refreshing data...
        </Text>
      )}

      <Button
        title='Book New Appointment'
        onPress={() => setScreen("book")}
        style={styles.primaryAction}
        disabled={isRefreshing}
      />

      <Text style={styles.sectionHeader}>
        Upcoming Appointments (
        {appointments.filter((a) => a.status === "booked").length})
      </Text>
      <FlatList
        data={appointments.filter((a) => a.status === "booked")}
        renderItem={renderAppointment}
        keyExtractor={(item) => item.id}
        ListEmptyComponent={
          <Text style={styles.emptyText}>No upcoming appointments.</Text>
        }
        scrollEnabled={false}
      />

      <Text style={styles.sectionHeader}>
        My Personal Health Records / Prescriptions ({prescriptions.length})
      </Text>
      <FlatList
        data={prescriptions}
        renderItem={renderPrescription}
        keyExtractor={(item) => item.id}
        ListEmptyComponent={
          <Text style={styles.emptyText}>No active prescriptions.</Text>
        }
        scrollEnabled={false}
      />
    </ScrollView>
  );
};

const PatientView: FC = () => {
  const [screen, setScreen] = useState<"dashboard" | "book">("dashboard");

  switch (screen) {
    case "book":
      return <PatientBookingScreen setScreen={setScreen} />;
    case "dashboard":
    default:
      return <PatientDashboard setScreen={setScreen} />;
  }
};

// --- 7. HEALTHCARE WORKER VIEW (User Role: 'worker') ---

interface WorkerNavigationParams {
  patientId?: string;
}
interface WorkerScreenProps {
  setScreen: (
    screen: "dashboard" | "issue-rx",
    params?: WorkerNavigationParams
  ) => void;
  patientId?: string;
}

const HWDashboard: FC<WorkerScreenProps> = ({ setScreen }) => {
  const { user, api } = useAuth();
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);

  const fetchData = useCallback(async () => {
    setIsRefreshing(true);
    if (!user) {
      setIsRefreshing(false);
      return;
    }
    try {
      const appsData: any[] = await api.getAppointments(user.id, user.role);

      const formattedApps: Appointment[] = appsData.map((a) => ({
        ...a,
        id: a._id,
        patientName: a.patientId?.name || "Unknown Patient",
        patientObjectId: a.patientId?._id || a.patientId, // Store the MongoDB ID for use in Rx issue
      }));

      setAppointments(formattedApps);
    } catch (error: any) {
      Alert.alert(
        "Data Load Error",
        `Failed to load appointments: ${error.message}. Ensure the Node.js server is running and initialized.`
      );
    } finally {
      setIsRefreshing(false);
    }
  }, [user]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const renderAppointment = ({ item }: { item: Appointment }) => (
    <Card style={styles.listItem}>
      <Text style={styles.listTitle}>Patient: {item.patientName}</Text>
      <Text style={styles.listDetail}>
        Time: {item.time} | Date: {item.date}
      </Text>
      <Text style={styles.listDetail}>Reason: {item.reason}</Text>
      <Text
        style={[
          styles.listStatus,
          item.status === "booked"
            ? styles.statusBooked
            : styles.statusFilled,
        ]}
      >
        Status: {item.status.toUpperCase()}
      </Text>
      {item.status === "booked" && (
        <Button
          title='Issue Prescription'
          onPress={() =>
            setScreen("issue-rx", { patientId: item.patientObjectId })
          }
          style={{ marginTop: 10, backgroundColor: "#28a745" }}
          disabled={isRefreshing}
        />
      )}
    </Card>
  );

  return (
    <ScrollView
      style={styles.screenContainer}
      contentContainerStyle={{ paddingBottom: 100 }}
      refreshControl={
        <RefreshControl
          refreshing={isRefreshing}
          onRefresh={fetchData}
          colors={[primaryColor]}
          tintColor={primaryColor}
        />
      }
    >
      <ScreenTitle>Worker Dashboard</ScreenTitle>
      <Text style={styles.subText}>
        Your daily schedule and patient roster.
      </Text>
      {isRefreshing && (
        <Text style={{ textAlign: "center", color: "#6c757d" }}>
          Refreshing data...
        </Text>
      )}

      <Text style={styles.sectionHeader}>
        Today's Appointments (
        {appointments.filter((a) => a.status === "booked").length})
      </Text>
      <FlatList
        data={appointments.filter((a) => a.status === "booked")}
        renderItem={renderAppointment}
        keyExtractor={(item) => item.id}
        ListEmptyComponent={
          <Text style={styles.emptyText}>No appointments today.</Text>
        }
        scrollEnabled={false}
      />
    </ScrollView>
  );
};

const IssuePrescriptionScreen: FC<WorkerScreenProps> = ({
  setScreen,
  patientId,
}) => {
  const { user, api } = useAuth();
  const [medication, setMedication] = useState<string>("");
  const [dosage, setDosage] = useState<string>("");
  const [instructions, setInstructions] = useState<string>("");
  const [isIssuing, setIsIssuing] = useState<boolean>(false);
  const [patient, setPatient] = useState<User | null>(null);

  useEffect(() => {
    const fetchPatient = async () => {
      if (patientId) {
        try {
          const p = await api.getUserDetails(patientId);
          setPatient(p || null);
        } catch (error: any) {
          Alert.alert(
            "Error",
            `Could not fetch patient details: ${error.message}`
          );
        }
      }
    };
    fetchPatient();
  }, [patientId]);

  const handleIssue = async () => {
    if (!medication || !dosage || !instructions || !user || !patientId) {
      Alert.alert("Error", "Please fill in all prescription details.");
      return;
    }
    setIsIssuing(true);
    try {
      await api.issuePrescription(
        patientId,
        user.id,
        medication,
        dosage,
        instructions
      );
      Alert.alert(
        "Success",
        `Prescription issued for ${
          patient?.name || "patient"
        } and delivered to their profile.`
      );
      setScreen("dashboard");
    } catch (error: any) {
      Alert.alert("Issue Failed", error.message);
    } finally {
      setIsIssuing(false);
    }
  };

  return (
    <ScrollView
      style={styles.screenContainer}
      contentContainerStyle={{ paddingBottom: 100 }}
    >
      <ScreenTitle>Issue Prescription</ScreenTitle>
      <Button
        title='← Back'
        onPress={() => setScreen("dashboard")}
        style={{ marginBottom: 20, backgroundColor: "#6c757d" }}
      />

      <Card style={{ marginBottom: 20 }}>
        <Text style={styles.sectionHeader}>
          Patient: {patient?.name || "Loading..."}
        </Text>
        <Text style={styles.listDetail}>
          Health ID: {patient?.healthId || "N/A"}
        </Text>
      </Card>

      <Text style={styles.label}>Medication Name</Text>
      <TextInput
        style={styles.input}
        value={medication}
        onChangeText={setMedication}
        placeholder='e.g., Atorvastatin'
      />

      <Text style={styles.label}>Dosage</Text>
      <TextInput
        style={styles.input}
        value={dosage}
        onChangeText={setDosage}
        placeholder='e.g., 20mg daily'
      />

      <Text style={styles.label}>Instructions</Text>
      <TextInput
        style={styles.textArea}
        value={instructions}
        onChangeText={setInstructions}
        multiline
        numberOfLines={4}
        placeholder='e.g., Take with evening meal. Do not crush.'
      />

      <Button
        title={isIssuing ? "Issuing..." : "Confirm & Issue Prescription"}
        onPress={handleIssue}
        disabled={isIssuing || !medication || !dosage || !instructions}
        style={{ marginTop: 20, backgroundColor: "#007bff" }}
      />
    </ScrollView>
  );
};

const WorkerView: FC = () => {
  const [screen, setScreen] = useState<"dashboard" | "issue-rx">("dashboard");
  const [params, setParams] = useState<WorkerNavigationParams>({});

  const navigate = (
    newScreen: "dashboard" | "issue-rx",
    newParams: WorkerNavigationParams = {}
  ) => {
    setScreen(newScreen);
    setParams(newParams);
  };

  switch (screen) {
    case "issue-rx":
      return (
        <IssuePrescriptionScreen
          setScreen={navigate}
          patientId={params.patientId}
        />
      );
    case "dashboard":
    default:
      return <HWDashboard setScreen={navigate} />;
  }
};

// --- 8. ADMIN VIEW (User Role: 'admin') ---

const AdminDashboard: FC = () => {
  const { api } = useAuth();
  const [users, setUsers] = useState<User[]>([]);
  const [editingUserId, setEditingUserId] = useState<string | null>(null);
  const [newRole, setNewRole] = useState<Role>("patient");
  const [isUpdating, setIsUpdating] = useState<boolean>(false);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);

  const fetchData = useCallback(async () => {
    setIsRefreshing(true);
    try {
      const allUsers: User[] = await api.getAllUsers();
      setUsers(allUsers.map((u) => ({ ...u, id: u._id })));
    } catch (error: any) {
      Alert.alert(
        "Error",
        `Failed to load user data: ${error.message}. Ensure the Node.js server is running and initialized.`
      );
    } finally {
      setIsRefreshing(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handleUpdateRole = async (userId: string) => {
    if (!newRole) {
      Alert.alert("Error", "Please select a new role.");
      return;
    }
    setIsUpdating(true);
    try {
      await api.updateRole(userId, newRole);
      Alert.alert("Success", `User ${userId} role updated to ${newRole}.`);
      setEditingUserId(null);
      setNewRole("patient");
      fetchData();
    } catch (error: any) {
      Alert.alert("Update Failed", error.message);
    } finally {
      setIsUpdating(false);
    }
  };

  const renderUserItem = ({ item }: { item: User }) => (
    <Card style={styles.adminListItem}>
      <View>
        <Text style={styles.listTitle}>Name: {item.name}</Text>
        <Text style={styles.listDetail}>Email: {item.email}</Text>
        <Text style={styles.listStatus}>
          Current Role: {item.role.toUpperCase()}
        </Text>
      </View>
      <Button
        title='Manage Role'
        onPress={() => {
          setEditingUserId(item.id);
          setNewRole(item.role);
        }}
        style={{ backgroundColor: "#ffc107", paddingVertical: 8 }}
      />
      {editingUserId === item.id && (
        <View style={styles.roleManager}>
          <Text style={styles.label}>Assign New Role:</Text>
          <View
            style={{
              flexDirection: "row",
              justifyContent: "space-between",
              marginBottom: 10,
            }}
          >
            {Object.values(ROLES).map((role: Role) => (
              <TouchableOpacity
                key={role}
                style={[
                  styles.roleOption,
                  newRole === role && styles.roleOptionSelected,
                ]}
                onPress={() => setNewRole(role)}
              >
                <Text
                  style={[
                    styles.roleOptionText,
                    newRole === role && styles.roleOptionTextSelected,
                  ]}
                >
                  {role.toUpperCase()}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
          <Button
            title={isUpdating ? "Updating..." : "Confirm Role Change"}
            onPress={() => handleUpdateRole(item.id)}
            disabled={isUpdating || newRole === item.role}
          />
        </View>
      )}
    </Card>
  );

  return (
    <View style={styles.screenContainer}>
      <ScreenTitle>System Administrator Dashboard</ScreenTitle>
      <Text style={styles.subText}>
        Manage user accounts, roles, and system health.
      </Text>
      {isRefreshing && (
        <Text style={{ textAlign: "center", color: "#6c757d" }}>
          Refreshing data...
        </Text>
      )}

      <Text style={styles.sectionHeader}>
        User Management ({users.length} Total Users)
      </Text>
      <FlatList
        data={users}
        renderItem={renderUserItem}
        keyExtractor={(item) => item.id}
        contentContainerStyle={{ paddingBottom: 100 }}
        refreshControl={
          <RefreshControl
            refreshing={isRefreshing}
            onRefresh={fetchData}
            colors={[primaryColor]}
            tintColor={primaryColor}
          />
        }
      />
    </View>
  );
};

// --- 9. MAIN APP COMPONENT & NAVIGATION ---
type AuthScreenName = "login" | "signup" | "forgot";

const AppContent: FC = () => {
  const { user, logout } = useAuth();
  const [authScreen, setAuthScreen] = useState<AuthScreenName>("login");

  let MainView: FC | null = null;
  if (user) {
    switch (user.role) {
      case ROLES.PATIENT:
        MainView = PatientView;
        break;
      case ROLES.HEALTH_WORKER:
        MainView = WorkerView;
        break;
      case ROLES.ADMIN:
        MainView = AdminDashboard;
        break;
      default:
        MainView = () => (
          <Text style={styles.textBase}>Unknown Role. Logging out...</Text>
        );
        setTimeout(logout, 2000);
        break;
    }
  }

  if (user && MainView) {
    return (
      <View style={styles.appContainer}>
        <NavHeader name={user.name} role={user.role} onLogout={logout} />
        <MainView />
      </View>
    );
  }

  const setAuthScreenTyped = setAuthScreen as (screen: AuthScreenName) => void;

  return (
    <View style={styles.appContainer}>
      {authScreen === "login" && <LoginScreen setScreen={setAuthScreenTyped} />}
      {authScreen === "signup" && (
        <SignUpScreen setScreen={setAuthScreenTyped} />
      )}
      {authScreen === "forgot" && (
        <ForgotPasswordScreen setScreen={setAuthScreenTyped} />
      )}
    </View>
  );
};

const App: FC = () => {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
};

export default App;

// --- 10. STYLES ---
const basePadding = 16;
const primaryColor = "#007bff";
const secondaryColor = "#28a745";
const dangerColor = "#dc3545";
const warningColor = "#ffc107";

const styles = StyleSheet.create({
  appContainer: {
    flex: 1,
    backgroundColor: "#f8f9fa",
    paddingTop: 40,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#fff",
  },
  screenContainer: {
    flex: 1,
    paddingHorizontal: basePadding,
  },
  // Header
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    padding: basePadding,
    backgroundColor: "#fff",
    borderBottomWidth: 1,
    borderBottomColor: "#dee2e6",
    marginBottom: 10,
  },
  headerText: {
    fontSize: 20,
    fontWeight: "bold",
    color: primaryColor,
  },
  headerSubText: {
    fontSize: 12,
    color: "#6c757d",
  },
  logoutButton: {
    backgroundColor: dangerColor,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
  },
  logoutButtonText: {
    color: "#fff",
    fontSize: 14,
    fontWeight: "600",
  },

  // Typography
  screenTitle: {
    fontSize: 28,
    fontWeight: "800",
    color: "#343a40",
    marginBottom: 8,
  },
  subText: {
    fontSize: 14,
    color: "#6c757d",
    marginBottom: 20,
  },
  textBase: {
    fontSize: 16,
    color: "#343a40",
  },
  sectionHeader: {
    fontSize: 20,
    fontWeight: "700",
    color: "#343a40",
    marginTop: 25,
    marginBottom: 10,
    borderLeftWidth: 4,
    borderLeftColor: primaryColor,
    paddingLeft: 10,
  },
  label: {
    fontSize: 16,
    fontWeight: "600",
    color: "#495057",
    marginTop: 15,
    marginBottom: 5,
  },

  // Auth & Input
  authContainer: {
    flex: 1,
    padding: basePadding * 2,
    justifyContent: "center",
  },
  inputCard: {
    marginBottom: 20,
    padding: 15,
    backgroundColor: "#fff",
  },
  input: {
    height: 50,
    borderColor: "#ced4da",
    borderWidth: 1,
    borderRadius: 8,
    paddingHorizontal: 15,
    marginBottom: 10,
    fontSize: 16,
  },
  textArea: {
    minHeight: 100,
    borderColor: "#ced4da",
    borderWidth: 1,
    borderRadius: 8,
    padding: 15,
    fontSize: 16,
    textAlignVertical: "top",
  },
  mockUserContainer: {
    marginTop: 30,
    padding: 15,
    borderRadius: 8,
    backgroundColor: "#e9ecef",
    borderLeftWidth: 5,
    borderLeftColor: warningColor,
  },
  mockUserTitle: {
    fontWeight: "bold",
    marginBottom: 5,
    color: "#343a40",
  },
  mockUserText: {
    fontSize: 12,
    color: "#495057",
  },
  // New layout for auth links
  authLinkContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginTop: 15,
    paddingHorizontal: 10,
  },
  forgotPasswordText: {
    color: "#6c757d",
    fontSize: 14,
    textDecorationLine: "underline",
  },
  switchButton: {
    alignSelf: "center",
    marginTop: 15,
  },
  switchButtonText: {
    color: primaryColor,
    fontSize: 16,
    textDecorationLine: "underline",
  },

  // Buttons
  button: {
    backgroundColor: primaryColor,
    padding: 15,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
    elevation: 3,
  },
  buttonText: {
    color: "#fff",
    fontSize: 18,
    fontWeight: "bold",
  },
  buttonDisabled: {
    backgroundColor: "#adb5bd",
  },
  primaryAction: {
    backgroundColor: secondaryColor,
    marginBottom: 20,
  },
  cancelButton: {
    backgroundColor: dangerColor,
    paddingVertical: 6,
    marginTop: 8,
  },
  cancelButtonText: {
    fontSize: 14,
    fontWeight: "600",
  },

  // Lists and Cards
  card: {
    backgroundColor: "#fff",
    borderRadius: 12,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
    padding: basePadding,
  },
  listItem: {
    marginBottom: 15,
    borderLeftWidth: 5,
    borderLeftColor: primaryColor,
  },
  listTitle: {
    fontSize: 18,
    fontWeight: "700",
    color: "#343a40",
    marginBottom: 4,
  },
  listDetail: {
    fontSize: 14,
    color: "#6c757d",
  },
  listStatus: {
    fontSize: 14,
    fontWeight: "700",
    marginTop: 5,
  },
  statusBooked: {
    color: primaryColor,
  },
  statusCancelled: {
    color: dangerColor,
  },
  statusFilled: {
    color: secondaryColor,
  },

  // Provider Tiles (Booking Screen)
  providerTile: {
    backgroundColor: "#fff",
    padding: 15,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: "#e9ecef",
    marginRight: 10,
    alignItems: "center",
    width: 120,
  },
  providerSelected: {
    borderColor: primaryColor,
    backgroundColor: "#e6f2ff",
  },
  providerName: {
    marginTop: 5,
    fontWeight: "600",
    textAlign: "center",
  },
  providerTitle: {
    fontSize: 12,
    color: "#6c757d",
    textAlign: "center",
  },
  datePickerButton: {
    backgroundColor: "#fff",
    padding: 15,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "#ced4da",
    marginBottom: 20,
  },
  dateSelected: {
    borderColor: secondaryColor,
    backgroundColor: "#f1fff5",
    borderWidth: 2,
  },
  datePickerText: {
    fontSize: 18,
    fontWeight: "bold",
    color: primaryColor,
  },
  datePickerTime: {
    fontSize: 14,
    color: "#6c757d",
    marginTop: 5,
  },
  emptyText: {
    fontSize: 16,
    color: "#6c757d",
    textAlign: "center",
    padding: 20,
    backgroundColor: "#f1f1f1",
    borderRadius: 8,
    marginTop: 10,
  },

  // Admin Styles
  adminListItem: {
    flexDirection: "column",
    justifyContent: "space-between",
    marginBottom: 15,
    padding: 15,
  },
  roleManager: {
    marginTop: 15,
    paddingTop: 10,
    borderTopWidth: 1,
    borderTopColor: "#e9ecef",
  },
  roleOption: {
    flex: 1,
    padding: 8,
    marginHorizontal: 4,
    borderRadius: 6,
    backgroundColor: "#f8f9fa",
    borderWidth: 1,
    borderColor: "#ced4da",
    alignItems: "center",
  },
  roleOptionSelected: {
    backgroundColor: primaryColor,
    borderColor: primaryColor,
  },
  roleOptionText: {
    fontSize: 12,
    fontWeight: "bold",
    color: "#495057",
  },
  roleOptionTextSelected: {
    color: "#fff",
  },

  guestButton: {
    marginTop: 12,
    paddingVertical: 12,
    alignItems: 'center',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#000',
  },
  guestButtonText: {
    color: '#000',
    fontWeight: '600',
  },
});
